from odoo import models,fields

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def get_product_stock(self):
        move_id_lst = []
        move_product_dict = []
        for move in self.move_line_ids:
            if move.product_id.name in move_id_lst:
                for i in move_product_dict:
                    if i['prod_id'] == move.product_id.name:
                        i['qty_done'] = i['qty_done'] + move.qty_done
                        i['lot_data'].append(move.lot_id.name)
            else:
                move_product_dict.append({
                    'prod_id':move.product_id.name,
                    'qty_done':move.qty_done,
                    'lot_data':[move.lot_id.name]
                })
                move_id_lst.append(move.product_id.name)
        return move_product_dict